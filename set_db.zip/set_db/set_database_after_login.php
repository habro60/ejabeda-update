<?php

if ($_SESSION['org_no'] == '1000000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_green_daru_apart");
	  $conn->set_charset("utf8");
	  $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_green_daru_apart;', 'myejabeda_root', 'Habro_124366');
	  $connect->exec("set names utf8");

}elseif ($_SESSION['org_no'] == '1100000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_bismillah");
	  $conn->set_charset("utf8");
	  $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_bismillah;', 'myejabeda_root', 'Habro_124366');
	  $connect->exec("set names utf8");

	
	} elseif ($_SESSION['org_no'] == '1200000000') {
   $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_kah_high_school");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_kah_high_school;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");

 } elseif ($_SESSION['org_no'] == '1300000000') {
    $conn = new mysqli("localhost:3306","root","","sheltech");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=sheltech;', 'root', '');
    $connect->exec("set names utf8");

}elseif ($_SESSION['org_no'] == '1400000000') {
    $conn = new mysqli("localhost:3306","myejabeda_green_da","Habro_124366","myejabeda_pastry_ghar");
	$conn->set_charset("utf8");
	$connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_pastry_ghar;', 'ejabeda_green_da', 'Habro_124366');
	$connect->exec("set names utf8");
	
  } elseif ($_SESSION['org_no'] == '1500000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_habro");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_habro;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");

  } elseif ($_SESSION['org_no'] == '1600000000') {
    $conn = new mysqli("localhost:3306","myejabeda_green_da","Habro_124366","myejabeda_15eng");
	$conn->set_charset("utf8");
	$connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_15eng;', 'ejabeda_green_da', 'Habro_124366');
	$connect->exec("set names utf8");

  
  }elseif ($_SESSION['org_no'] == '1700000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_landmark_Apt");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_landmark_Apt;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");
 
  }elseif ($_SESSION['org_no'] == '1800000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_banik");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_banik;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");

  }elseif ($_SESSION['org_no'] == '1900000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_hashem");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_hashem;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");

  }elseif ($_SESSION['org_no'] == '2000000000') {
   $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_darululo_dhaka");
	  $conn->set_charset("utf8");
	  $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_darululo_dhaka;', 'myejabeda_root', 'Habro_124366');
	  $connect->exec("set names utf8");


}elseif ($_SESSION['org_no'] == '2100000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_karna");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_karna;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");

}elseif ($_SESSION['org_no'] == '2200000000') {
    $conn = new mysqli("localhost:3306","myejabeda_green_da","Habro_124366","myejabeda_rupganj_somaj");
	$conn->set_charset("utf8");
	$connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_rupganj_somaj;', 'ejabeda_green_da', 'Habro_124366');
	$connect->exec("set names utf8");

}elseif ($_SESSION['org_no'] == '2400000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_dapunia_somity");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_dapunia_somity;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");
	
  }elseif ($_SESSION['org_no'] == '2500000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_asrafunnesa_mohila_madrasa");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_asrafunnesa_mohila_madrasa;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");
	
  }elseif ($_SESSION['org_no'] == '5000000000') {
    $conn = new mysqli("localhost:3306","myejabeda_root","Habro_124366","myejabeda_demo");
    $conn->set_charset("utf8");
    $connect = new PDO('mysql:host=localhost:3306; dbname=myejabeda_demo;', 'myejabeda_root', 'Habro_124366');
    $connect->exec("set names utf8");
  }
