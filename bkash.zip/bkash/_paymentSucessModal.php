<div class="modal fade" id="payment-success-modal" tabindex="-1" role="dialog" aria-labelledby="payment-success-modal-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

            </div>


            <div class="modal-body ">

                <div class="text-center">
                    <i class="fa-regular fa-circle-check" style="color: #62b3d5; font-size: 70px; margin-bottom:25px;"></i>
                    <h4>Payment Successful</h4>

           

                </div>

            </div>
        </div>
    </div>
</div>