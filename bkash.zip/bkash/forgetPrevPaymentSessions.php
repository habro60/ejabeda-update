<?php


unset($_SESSION['bkash_token']);
unset($_SESSION['refresh_token']);
unset($_SESSION['agreementID']);
unset($_SESSION['paymentID']);
unset($_SESSION['customerBkashAccount']);
unset($_SESSION['invoiceNo']);
unset($_SESSION['trxId']);
