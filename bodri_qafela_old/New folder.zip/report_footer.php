<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:20px;
   background-color: gray;
   color: white;
   text-align: center;
}
</style>
<div class="footer">
  <p>HABRO SYSTEMS LIMITED</p>
</div>